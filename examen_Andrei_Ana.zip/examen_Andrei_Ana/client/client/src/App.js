import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import {useEffect, useState} from 'react';

function App() {
  // const link="http://localhost:8000/api/";
  // const linksAPICall={
  //   getLinkVS : link + "VirtualShelfs",     
  //   postLink: link + "postElement", 
  //   putLink: link + "putElement/",  
  //   deleteLink : link + "deleteElement/"   

  // }
  // async function getDataVS(){
  //   let data=(await axios.get(linksAPICall.getLinkVS)).data;
  //   return data;
  // }

  // const dataVS=getDataVS();

  const data=[
    {VirtualShelfsId:"1",VirtualShelfDescription:"Descriere"},
    {VirtualShelfsId:"2",VirtualShelfDescription:"Desada"}
  ]
  const books=[
    {BooksId:"1",BooksTitle:"ceva",VirtualShelfId:"1"},
    {BooksId:"2",BooksTitle:"altceva",VirtualShelfId:"2"}
  ]

  // state = {
  //   rows: []
  // };
  // handleChange = idx => e => {
  //   const { name, value } = e.target;
  //   const rows = [...this.state.rows];
  //   rows[idx] = {
  //     [name]: value
  //   };
  //   this.setState({
  //     rows
  //   });
  // };
  // handleAddRow = () => {
  //   const item = {
  //     name: "",
  //     mobile: ""
  //   };
  //   this.setState({
  //     rows: [...this.state.rows, item]
  //   });
  // };
  // handleRemoveRow = () => {
  //   this.setState({
  //     rows: this.state.rows.slice(0, -1)
  //   });
  // };


  return (
    <div className="App">
      <table>
        <tr>
          <th>VirtualShelfsId</th>
          <th>VirtualShelfDescription</th>
        </tr>
        {data.map((val, key) => {
          return (
            <tr key={key}>
              <td>{val.VirtualShelfsId}</td>
              <td>{val.VirtualShelfDescription}</td>
            </tr>
          )
        })}
      </table>
      <button>Adauga Raft</button>
      <button>Sterge Raft</button>
      <br></br>
      <table>
        <tr>
          <th>BooksId</th>
          <th>BooksTitle</th>
          <th>VirtualShelfsId</th>
        </tr>
        {books.map((val, key) => {
          return (
            <tr key={key}>
              <td>{val.BooksId}</td>
              <td>{val.BooksTitle}</td>
              <th>{val.VirtualShelfsId}</th>
            </tr>
          )
        })}
      </table>
      <button >Adauga Carte</button>
      <button>Sterge Carte</button>



    </div>
  );
}

export default App;

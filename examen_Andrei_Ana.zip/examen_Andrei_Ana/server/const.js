export const DB_USERNAME='root'
export const DB_PASSWORD='Varapreferatamea1*'
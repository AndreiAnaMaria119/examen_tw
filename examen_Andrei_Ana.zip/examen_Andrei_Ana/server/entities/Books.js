import { count } from 'console';
import Sequelize from 'sequelize';
import db from '../dbConfig.js';


//entitatea COPIL- un raft are mai multe carti
const Books=db.define("Books",{
    BooksId:{
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    BooksTitle:{
        type: Sequelize.STRING,  
        allowNull: false,
        validate: { len: 5 }
    },
    BooksCategory:{
        type: Sequelize.STRING,
        allowNUll: true,
        validate:{
            function(value){
                if(value!=="comedy"||value!=="drama"|| value!=="action"){
                    throw new Error(" you should choose between drama, comedy or  action");

                }

            }
        }
    },
    BooksURL:{
        type: Sequelize.STRING,
        allowNUll: true,
        validate:{
            isUrl:true
        }
    },
    VirtualShelfId:{
        type: Sequelize.INTEGER,
        allowNull: true
        // validate:{
        //     function(id){
        //         db.VirtualShelf.count({where:{VirtualShelfId : id}}).then(count=>{
        //             if(count==0){
        //                 throw new Error("Virtual Shelf does not exists");
        //             }
        //         })
        //     }
        // }
    }

})

export default Books;
import Sequelize from 'sequelize';
import db from '../dbConfig.js';

//definesc enetitatea care va fi mapata la o tabela 
//entitatea parinte
const VirtualShelf=db.define("VirtualShelf",{
    VirtualShelfId:{
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    VirtualShelfDescription:{
        type: Sequelize.STRING,  
        allowNull: false,
        validate: { len: 3 }
    },
    VirtualShelfDate:{
        type: Sequelize.DATE,
        allowNUll: false
    }

})

export default VirtualShelf;
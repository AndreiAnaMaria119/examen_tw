
//////////////////////////////////////////////imi definesc API//////////////////////////////////////////////////
import express from 'express';                                                                             /////
import bodyParser from 'body-parser';                                                                     /////
import cors from 'cors';
                                                                                                         /////
                                                                                                         /////
 // creez apl simpla de tip express                                                                     /////
let app=express();                                                                                    /////

 //creez rute
let router=express.Router();

 //CONFIGURARI PENTRU REQUESTURI DE TIP POST/PUT
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.use(cors());
app.use('/api',router);

 //DEFINESC UN PORT
let port=process.env.PORT || 8000;
app.listen(8000);
console.log("API is running at "+ port);

/////////////////////////////////////////////////////////imi definesc baza de date si tabelele//////////////////////////////////////
import mysql from 'mysql2/promise';
import { DB_USERNAME, DB_PASSWORD } from './const.js';
import db from './dbConfig.js';
import VirtualShelf from './entities/VirtualShelf.js';
import Books from './entities/Books.js';

//conexiunea
let conn;
mysql.createConnection({
    user: DB_USERNAME,
    password: DB_PASSWORD
})
.then(connection =>{
    conn=connection;
    return connection.query("CREATE DATABASE IF NOT EXISTS VirtualLibrary")
})
.then(()=>{
    return conn.end();
})
.catch(err=>{
    console.warn(err.stack)
})
//////am creat bd////////

//relatia dintre cele doua enitati
VirtualShelf.hasMany(Books,{ as: "Books", foreignKey:"VirtualShelfId"});
Books.belongsTo(VirtualShelf,{foreignKey:"VirtualShelfId"});

router.route('/create').get(async(req, res)=>{
    try{
        await db.sync(); //face sincronizarea intre tabele si entitati
        res.status(201).json({message: "created"})
    } catch( err){
        console.warn(err.stack)
        res.status(500).json({message: "Internal server error"})
    }
})

// am creat tabelele
///////////////////////////////////////////////////////////////post Entitati
async function createVirtualShelf(vs){
    return await VirtualShelf.create(vs,{include: [{model: Books, as: "Books"}]});
}
router.route('/createVS').post(async(req, res)=>{
    return res.send(201).json(await createVirtualShelf(req.body));
})

//in post man au mers validarile si inserarile
async function createBooks(book){
    return await Books.create(book);
}
router.route('/createBK').post(async(req, res)=>{
    return res.send(201).json(await createBooks(req.body));
})
//in post man au mers validarile si inserarile

////////////////////////////////////////////////////////////////get Entitati

async function getVirtualShelfs(){
    return await VirtualShelf.findAll({
        include:["Books"]
    });
}
router.route('/VirtualShelfs').get(async(req,res)=>{
    return res.json(await getVirtualShelfs());
})

async function getBooks(){
    return await Books.findAll();
}
router.route('/Books').get(async(req,res)=>{
    return res.json(await getBooks());
})

//getBooks by id
async function getBooksById(id){
    return await Books.findByPk(id);
}
router.route('/Books/:id').get(async(req,res)=>{
    try{
        return res.json(await getBooksById(req.params.id));
    }
    catch(e){
        console.warn(e.message);
    }
    
})




/////////////////////////////////////////////////////////////////////put entitati
//put pentru copil
async function updateBook(id, book){
    if(parseInt(id)!==parseInt(book.BooksId)){
        console.log(id+book.BooksId);
        return;
    }

    let updateEntity= await getBooksById(id);

    if(!updateEntity){
        console.log("Nu exista acesta carte");
        return;
    }

    return await updateEntity.update(book);
}

router.route('/Books/:id').put(async(req, res)=>{
    try{
        return res.json(await updateBook(req.params.id, req.body));
    } catch(e){
        console.warn(e.message);
    }
})

//put pentru parinte
async function updateShelf(id, shelf){
    if(parseInt(id)!==parseInt(shelf.VirtualShelfId)){
        console.log(id+shelf.VirtualShelfId);
        return;
    }

    let updateEntity= await getShelfById(id);

    if(!updateEntity){
        console.log("Nu exista acest raft");
        return;
    }

    return await updateEntity.update(shelf);
}

router.route('/VirtualShelfs/:id').put(async(req, res)=>{
    try{
        return res.json(await updateShelf(req.params.id, req.body));
    } catch(e){
        console.warn(e.message);
    }
})
//nu se poate edita vectorul de carti

/////////////////////////////////////////////////////////////////////delete entitati
//delete copil
async function deleteBook(id){

    let deleteEntity= await getBooksById(id);

    if(!deleteEntity){
        console.log("Nu exista acesta carte");
        return;
    }

    return await deleteEntity.destroy();
}

router.route('/Books/:id').delete(async(req, res)=>{
    try{
        return res.json(await deleteBook(req.params.id));
    } catch(e){
        console.warn(e.message);
    }
})

//delete parinte
async function deleteShelf(id){

    let deleteEntity= await getShelfById(id);

    if(!deleteEntity){
        console.log("Nu exista acest raft");
        return;
    }

    return await deleteEntity.destroy();
}

router.route('/VirtualShelfs/:id').delete(async(req, res)=>{
    try{
        return res.json(await deleteShelf(req.params.id));
    } catch(e){
        console.warn(e.message);
    }
})


////////////////////////filtrare si sortare
////////dupa doua campuri prima entitate

//prima filtrare - dupa descriere
async function getVirtualShelfByDescription(description){
    return await VirtualShelf.findAll({where: description ? {VirtualShelfDescription : description}:undefined});
}
router.route('/VirtualShelfsFilterOne').get(async(req,res)=>{
    return res.json(await getVirtualShelfByDescription(req.query.description));
})

//a doua filtrare - dupa id
//get Shelf by id
async function getShelfById(id){
    return await VirtualShelf.findByPk(id);
}
router.route('/VirtualShelfs/:id').get(async(req,res)=>{
    try{
        return res.json(await getShelfById(req.params.id));
    }
    catch(e){
        console.warn(e.message);
    }
    
})

// dupa doua campuri in acelasi timp
// import LikeOp from './Operator.js';
// async function filtrareTrei(filter){
//     let whereClause={};
//     if(filter.VirtualShelfDescription){
//         whereClause.VirtualShelfDescription={[LikeOp]: `%${filter.VirtualShelfDescription}%` }

//     }
//     if(filter.VirtualShelfId){
//         whereClause.VirtualShelfId={[LikeOp]: `%${filter.VirtualShelfId}%` }

//     }

//     return await VirtualShelf.findAll({
//         include:[
//             {
//                 model: Books,
//                 as: "Books",
//                 where: whereInlcudeClause
//             }
//         ],
//         where: whereClause
//     })
// }
// router.route('/VirtualShelfsFilterTrei').get(async(req,res)=>{
//     return res.json(await filtrareTrei(req.query));
// })

//sortare dupa un camp prima entitate
async function sortShelfById(){
    return await VirtualShelf.findAll({
        order:[
            ['VirtualShelfId', 'DESC']
        ]
    });
}
router.route('/SortVirtualShelfs').get(async(req,res)=>{
    try{
        return res.json(await sortShelfById());
    }
    catch(e){
        console.warn(e.message);
    }
    
})


///import export baza de date
import fastcsv from "fast-csv"
import fs from "fs"
// const ws = fs.createWriteStream("db.csv");
//     conn.query("SELECT * FROM virtualshelf", function(error, data, fields) {
//         if (error) throw error;
//         const jsonData = JSON.parse(JSON.stringify(data));
//         fastcsv.write(jsonData, {headers:true}).pipe(ws);
//     });